export { default as ProductManagement } from './ProductManagement';
export { default as ProductCatalog } from './ProductCatalog';
export { default as ProductSpecifications } from './ProductSpecifications';
export { default as PricingManagement } from './PricingManagement';
export { default as InventoryTracking } from './InventoryTracking';